AccessLearn Ethiopia portable sample

Open index.html in a modern browser. The package includes local media, English captions,
an unreviewed Amharic draft, and transcript JSON. The EthSL window control demo is not
a sign-language interpretation recording. Educators must upload a rights-cleared,
human-recorded and reviewed EthSL video before production publication.